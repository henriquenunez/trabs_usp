### Exercicios dados em 01/11/19
