#ifndef _MERGE_SORT_H
#define _MERGE_SORT_H

int mergeSort(int* vec, int size);

#endif