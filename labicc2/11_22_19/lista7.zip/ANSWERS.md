# Lista de exercícios 7

Número USP: 11275300

## Teste de mesa (questão 1):

```
0
aux is: 4
1 1 2 7 5 3 0 0
1 1 2 7 5 3 0 0
1 1 0 7 5 3 2 0
1 1 0 0 5 3 2 7
aux is: 2
0 1 1 0 5 3 2 7
0 0 1 1 5 3 2 7
0 0 1 1 5 3 2 7
0 0 1 1 5 3 2 7
0 0 1 1 2 3 5 7
0 0 1 1 2 3 5 7
aux is: 1
0 0 1 1 2 3 5 7
0 0 1 1 2 3 5 7
0 0 1 1 2 3 5 7
0 0 1 1 2 3 5 7
0 0 1 1 2 3 5 7
0 0 1 1 2 3 5 7
0 0 1 1 2 3 5 7
0
```

##Tempos encontrados (questão 5):

```
predef: original
not_predef: modificado

100 valores:
time is(predef): 0.000037
time is(not_predef): 0.000012

1000 valores:
time is(predef): 0.000697
time is(not_predef): 0.000242

10000 valores:
time is(predef): 0.005307
time is(not_predef): 0.000640

100000 valores:
time is(predef): 0.030655
time is(not_predef): 0.006802
```
