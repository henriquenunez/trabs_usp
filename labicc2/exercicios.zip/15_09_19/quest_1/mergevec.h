#ifndef MERGEVEC_H
#define MERGEVEC_H

typedef struct _finishParams finishParams;

int* mergeVecs(int vecA[], int vecB[], int sizeA, int sizeB);

#endif