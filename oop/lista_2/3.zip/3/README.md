# Shapes

Works on Java 8+

```
make #builds and runs application
make run #only runs application
```
