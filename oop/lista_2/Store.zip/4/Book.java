package store;

public class Book extends Product {

}
