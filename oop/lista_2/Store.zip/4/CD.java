package store;

public class CD extends Product {

}
