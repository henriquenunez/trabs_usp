package store;

public class DVD extends Product {

}
