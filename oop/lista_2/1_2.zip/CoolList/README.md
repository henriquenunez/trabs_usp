# CoolList

The coolest contact list you have ever seen!

usage:

```
make build #Compiles packages
make run #Runs entry point
#or simply
make
```
