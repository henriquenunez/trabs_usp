Arquivo zip gerado em: 05/11/2019 21:50:40 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 5 - Calculadora Polonesa Reversa