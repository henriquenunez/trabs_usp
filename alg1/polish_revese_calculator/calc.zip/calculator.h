#ifndef _CALCULATOR_H_
#define _CALCULATOR_H_

float make_things_work(char*);

#endif
