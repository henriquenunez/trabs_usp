#ifndef _DEFINES_H_
#define _DEFINES_H_


#define SUCCESS 0
#define NULL_POINTER_EXCEPTION -69
#define ERROR -1
#define MEMORY_ERROR 64

#endif