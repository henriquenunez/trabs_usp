#ifndef _DEFINES_H_
#define _DEFINES_H_

#define SUCESSO 0
#define ERRO -1
#define INEXISTE -2
#define EXISTE -3

#define max(a,b) (a > b ? a : b)

#endif

