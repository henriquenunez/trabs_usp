#ifndef DEFS_H
#define DEFS_H

#define OK 0
#define NULL_PTR_ERR -1
#define NOT_AVAILABLE -2

#define MAX_CARS_P 5
#define MAX_CARS_F 10

typedef unsigned char short_number_t;

#endif
