#include <stdio.h>
#include <stdlib.h>

#include "stack.h"

int main()
{
	

	return 0;
}