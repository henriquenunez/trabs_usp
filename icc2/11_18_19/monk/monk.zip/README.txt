Arquivo zip gerado em: 28/11/2019 04:26:20 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Hash do Monk - Turma 2