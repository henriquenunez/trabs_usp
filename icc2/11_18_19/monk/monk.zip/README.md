### Aula de exercicios 18/11/2019.
