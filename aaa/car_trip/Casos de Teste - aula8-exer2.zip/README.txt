Arquivo zip gerado em: 06/11/2020 20:23:31 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: aula8-exer2