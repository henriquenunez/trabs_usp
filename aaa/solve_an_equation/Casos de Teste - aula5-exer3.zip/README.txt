Arquivo zip gerado em: 09/10/2020 15:09:00 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: aula5-exer3