Arquivo zip gerado em: 03/12/2020 18:23:17 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: aula10-exer1