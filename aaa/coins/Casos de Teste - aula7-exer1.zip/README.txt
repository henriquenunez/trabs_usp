Arquivo zip gerado em: 04/11/2020 19:21:08 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: aula7-exer1